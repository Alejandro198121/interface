package view;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class VistaEmergente {
	private Scanner leer;
	
	public VistaEmergente() {
		leer = new Scanner(System.in);
	}
	
	public void mostrarMensaje(String mensaje) {
		JOptionPane.showMessageDialog(null, mensaje);
	}
}
