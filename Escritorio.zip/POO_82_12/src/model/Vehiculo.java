package model;

public interface Vehiculo {

	String arrancar();
	String detener();
	default String clacson() {
		return "Haciendo sonar el clacson ";
	}
}
