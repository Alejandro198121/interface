package model;

public class Bicicleta implements Vehiculo {

	@Override
	public String arrancar() {
		return "pedalear";
	}

	@Override
	public String detener() {
		return "frenar cicla";
	}

}
