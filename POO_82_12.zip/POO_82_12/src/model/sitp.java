package model;

public class sitp implements Vehiculo{

	@Override
	public String arrancar() {
		return "arrancar el bus";
	}

	@Override
	public String detener() {
		return "Frenar el bus";
	}
	
}
