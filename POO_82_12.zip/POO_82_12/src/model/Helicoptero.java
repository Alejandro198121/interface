package model;

public class Helicoptero implements Vehiculo{

	@Override
	public String arrancar() {
		return "moviendo las helices a gran velocidad";
	}

	@Override
	public String detener() {
		return "dirigiendo el helicoptero a tierra";
	}

}
