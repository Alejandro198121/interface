package controller;

import model.Bicicleta;
import model.Helicoptero;
import model.sitp;
import view.VistaEmergente;

public class Controller {

	private VistaEmergente vista;
	private sitp vehiculo;
	private Bicicleta bici;
	private Helicoptero helicotero;
	public Controller() {
		vista = new VistaEmergente();
		vehiculo = new sitp();
		bici = new Bicicleta();
		helicotero = new Helicoptero();
		funcionar();
	}
	public void funcionar(){
		vista.mostrarMensaje("sitp:\n" + vehiculo.arrancar() + "\n" + vehiculo.detener() + "\n" +
				vehiculo.clacson());
		
		vista.mostrarMensaje("bici:\n"+ bici.arrancar() + "\n" + bici.detener() + "\n" + bici.clacson());
		vista.mostrarMensaje("Helicoptero:\n"+helicotero.arrancar() + "\n" + helicotero.detener() + "\n" + helicotero.clacson());
	}
}
