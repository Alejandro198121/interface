package model;

public interface SuperFuerza {

	String golpear();
	String lanzar();
	String empujar(int distancia);
	String levantar();
	String saltar(int distancia);
}
