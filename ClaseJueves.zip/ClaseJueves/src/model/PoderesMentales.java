package model;

public interface PoderesMentales {
	String leerMentes();
	String moverObjetos();
	String crearIlusiones();
	String controlarMentes();

}
