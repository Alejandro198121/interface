package model;

public interface Magia {
	String lanzarHechizos();
	String transformarse(String opcion);
	String teletransportarse();
	String invisibilidad();


}
