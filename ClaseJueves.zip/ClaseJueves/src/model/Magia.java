package model;

public interface Magia {
	String lanzarHechizos();
	//void transformarse(String opcion);
	String transformarse(String opcion);
	String teletransportarse();
	String invisibilidad();


}
